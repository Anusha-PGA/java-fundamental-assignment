package com.heraizen.cj.numberOperation;

import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;

public class NumberOperationsTest {

	NumberOperation obj = new NumberOperation();

	@Test
	public void isPrimeTest() {
		assertEquals(true, obj.isPrime(13));
	}

	@Test
	public void isNotPrimeTest() {
		assertEquals(true, obj.isPrime(11));
	}

	@Test
	public void isPrimeNegativeTest() {
		assertEquals(false, obj.isPrime(-12));
	}

	@Test
	public void evenPrimeCheckTest() {
		assertEquals(true, obj.isPrime(2));
	}

	@Test
	public void evenNotPrimeCheckTest() {
		assertEquals(false, obj.isPrime(4));
	}

	@Test
	public void isPalindromeTest() {
		assertEquals(true, obj.isPalindrome(424));
	}

	@Test
	public void isNotPalindromeTest() {
		assertEquals(false, obj.isPalindrome(46574));
	}

	@Test
	public void isPalindromeStrTest() {
		assertEquals(true, obj.isPalindromeStr("madam"));
	}

	@Test
	public void isNotPalindromeStrTest() {
		assertEquals(false, obj.isPalindromeStr("anu"));
	}

	@Test
	public void reverseTest() {
		assertEquals(321, obj.reverse(123));
	}

	@Test
	public void reverse2Test() {
		assertEquals(32, obj.reverse(23));
	}
	
	@Test
	public void reverse3Test() {
		assertEquals(32, obj.reverse(23));
	}
	@Test
	public void reverseNegaTest() {
		assertEquals(32, obj.reverse(-23));
	}
	
	@Test
	public void FindKeyTest() {
		int[] InpArr= {1,2,3,4,5},testArr= {0,1};
		assertEquals(Arrays.toString(testArr), Arrays.toString(obj.findPosInArrayWhoseSumIsEqualToKey(InpArr,3)));
	}
	@Test
	public void FindKeyAbsentTest() {
		int[] InpArr= {1,2,3,4,5},testArr= {0,1};
		assertEquals(null, obj.findPosInArrayWhoseSumIsEqualToKey(InpArr,20));
	}
	


}
