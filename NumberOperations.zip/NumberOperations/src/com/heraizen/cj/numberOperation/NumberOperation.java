package com.heraizen.cj.numberOperation;

public class NumberOperation {
	public boolean isPrime(int num) {
		if (num < 1)
			return false;
		if (num != 2 && num % 2 == 0)
			return false;
		for (int i = 2; i < ((int) Math.sqrt(num)); i++) {
			if (num % i == 0)
				return false;
		}
		return true;
	}

	public boolean isPalindrome(int num) {
		int revNum = 0, original = Math.abs(num), digit;
		boolean flag = true;
		while (num > 0) {
			digit = num % 10;
			revNum = (revNum * 10) + digit;
			num = num / 10;

		}
		if (original != revNum) {
			flag = false;
		}
		return flag;
	}

	public boolean isPalindromeStr(String str) {
		String revStr = "", original = str.toLowerCase();
		boolean flag = true;
		for (int i = original.length() - 1; i >= 0; i--) {
			revStr += original.charAt(i);
		}

		if (!original.equals(revStr)) {
			flag = false;
		}
		return flag;
	}

	public int reverse(int num) {
		int revNum = 0, digit;
		num = Math.abs(num);
		while (num > 0) {
			digit = num % 10;
			revNum = (revNum * 10) + digit;
			num = num / 10;

		}
		return revNum;
	}

	public int[] findPosInArrayWhoseSumIsEqualToKey(int[] InpArr, int key) {
		for (int i = 0; i < InpArr.length; i++) {
			for (int j = 0; j < InpArr.length; j++) {
				if (InpArr[i] + InpArr[j] == key) {
					int[] arr = {i , j};
					return arr;
				}
			}
		}
		return null;
	}

}
