package com.heraizen.cj.numberOperation;

import java.util.Arrays;

public class NumberOperation {

	public boolean isPrime(int num) {
		if (num <= 1)
			return false;
		if (num != 2 && num % 2 == 0)
			return false;
		for (int i = 2; i <= ((int) Math.sqrt(num)); i++) {
			if (num % i == 0)
				return false;
		}
		return true;
	}

	public boolean isPalindromeStr(String str) {
		String revStr = "", original = str.toLowerCase();
		boolean flag = true;
		for (int i = original.length() - 1; i >= 0; i--) {
			revStr += original.charAt(i);
		}

		if (!original.equals(revStr)) {
			flag = false;
		}
		return flag;
	}

	// Basic Data Types

	// 1. Write a program to accept the number from the user and print the factorial
	// of that number?

	public int factorial(int num) {
		if (num < 1) {
			return 0;
		}
		if (num == 1 || num == 0) {
			return 1;
		}
		return num * factorial(num - 1);
	}

	// 2. Write a program to list all even numbers less than or equal to the number
	// N. Take the value of N as
	// input from user.

	public int[] generateEvenNos(int num) {
		int[] resultArr = {};
		if (num <= 1) {
			return resultArr;
		}
		int size = num / 2;
		resultArr = new int[size - 1];
		if (num <= 1) {
			return resultArr;
		}
		for (int i = 2, j = 0; i < num; i++) {
			if (i % 2 == 0) {
				resultArr[j++] = i;
			}
		}
		return resultArr;
	}

	// 3. Write a program to accept the lower bound and upper bound values from the
	// user and print the prime
	// numbers between lower and upper bound.
	public int[] generatePrimeNos(int lb, int ub) {
		int[] resultArr = new int[range(lb, ub)];
		if ((ub < 0) || lb > ub) {
			return resultArr;
		}
		for (int i = lb, j = 0; i <= ub; i++) {
			if (isPrime(i)) {
				resultArr[j++] = i;

			}
		}
		return resultArr;
	}

	public int range(int lb, int ub) {// to findout size of array
		int counter = 0;
		for (int i = lb; i <= ub; i++) {
			if (isPrime(i)) {
				counter++;
			}
		}
		return counter;
	}

	// 4. Write a program to accept the five digit number from the user and do the
	// following
	// 4.1. Palindrome or not

	public boolean isPalindrome(int num) {
		int revNum = 0, original = Math.abs(num), digit;
		boolean flag = true;
		while (num > 0) {
			digit = num % 10;
			revNum = (revNum * 10) + digit;
			num = num / 10;

		}
		if (original != revNum) {
			flag = false;
		}
		return flag;
	}

	// 4.2. Reverse the given number

	public int reverse(int num) {
		int revNum = 0;
		num = Math.abs(num);
		while (num > 0) {

			revNum = (revNum * 10) + num % 10;
			num = num / 10;

		}
		return revNum;
	}

	// 4.3. Sum of the digits of the given number

	public int sumOfDigits(int num) {
		int sum = 0, digit;
		num = Math.abs(num);
		while (num > 0) {
			digit = num % 10;
			sum = sum + digit;
			num = num / 10;

		}
		return sum;
	}

	/*
	 * 5. A) Write a program to accept a 5 digit number and a digit from the user.
	 * Find the occurrence of the given digit in the given number?
	 */
	public int findOccurrenceOfKey(int num, int key) {
		int digit, count = 0;
		num = Math.abs(num);
		while (num > 0) {
			digit = num % 10;
			if (digit == key)
				count++;
			num = num / 10;
		}
		return count;
	}

	/*
	 * b)Find the sum of the digits of the number until you get a single digit sum.
	 * Ex: No is 99999 Sum should be 4+5 = 9
	 */
	public int findSumOfDigitTillZero(int num) {
		int sum = Math.abs(num), digit;
		num = Math.abs(num);
		while (sum > 10) {
			sum = 0;
			while (num > 0) {
				digit = num % 10;
				sum = sum + digit;
				num = num / 10;

			}
			num = sum;
		}
		return sum;
	}

	/*
	 * 1. Write a method to accept an array and key of type integer as parameters
	 * and find two elements in the array such that their sum is equal to given key.
	 * Example: Array is: {7,3,4,2,8,9} and key = 9 Output: 0, 3 (positions)
	 */

	public int[] findPosInArrayWhoseSumIsEqualToKey(int[] InpArr, int key) {
		for (int i = 0; i < InpArr.length; i++) {
			for (int j = 0; j < InpArr.length; j++) {
				if (InpArr[i] + InpArr[j] == key) {
					int[] arr = { i, j };
					return arr;
				}
			}
		}
		return null;
	}

	/*
	 * 2. Write a program to accept the string and remove the duplicate characters
	 * from the given string. Example: String: “jcljava” Output: “jclav”
	 */

	public String removeDuplication(String inputStr) {

		String str = "";
		for (int i = 0; i < inputStr.length(); i++) {
			Character ch = inputStr.charAt(i);
			if (!str.contains(ch.toString()))
				str += ch;

		}
		return str;

	}

	/*
	 * 3. Write a program to find the sum of first ‘N’ Fibonacci series. Example: If
	 * N= 6, the series is (0+1+1+2+3+5); Sum = 12
	 */
	public int fibonacci(int num) {
		if (num < 0)
			return 0;
		if (num == 1)
			return 1;
		int a = 0, b = 1, c;
		int sum = a + b;
		for (int i = 2; i < num; i++) {
			c = a + b;
			a = b;
			b = c;
			sum = sum + c;

		}
		return sum;

	}
	//
	// 4.
	// Write a program to find the Greatest Common Divisor (GCD) of three numbers.
	// Example:
	// Three numbers: 35, 42, 63; GCD = 7

	public int gcdOfThreeNo(int a, int b, int c) {
		return gcd(a, gcd(b, c));
	}

	public int gcd(int a, int b) {
		if (a == 0)
			return b;
		return gcd(b % a, a);
	}

	// 5.
	// Write a program to find the sum of positive numbers and negative numbers in
	// the given M x N
	// matrix.
	// Example:
	// In a given matrix:
	// 1 -2 3
	// 2 5 -8
	// 4 6 -4
	// The sum of +ve numbers: 21
	// The Sum of –ve numbers: -14

	public int[] sumOfPositiveAndNegativeNo(int[][] mat) {
		int[] resArr = new int[2];
		int posSum = 0, negSum = 0;
		for (int i = 0; i < 3; i++)
			for (int j = 0; j < 3; j++) {
				if (mat[i][j] > 0)
					posSum = posSum + mat[i][j];
				else
					negSum = negSum + mat[i][j];
			}
		resArr[0] = posSum;
		resArr[1] = negSum;
		return resArr;
	}

	// 6.
	// In the following array, consecutive numbers are stored but 1 number is
	// missing. These numbers
	// are not stored in any particular order. Write a program to determine the
	// missing number.
	// Array : [1,2,5,3,6,7,9,8] missing value is: 4

	public String missingNumbers(int[] inpArr) {
		String str = "";
		Arrays.sort(inpArr);
		for (int i = 0, j = inpArr[0]; i < inpArr.length; i++, j++) {
			if (j != inpArr[i])
				if (str != "")
					str = str + "," + j++;
				else
					str = str + j++;
		}
		return str;
	}

	// 7. Write a program to generate first 'N' prime numbers.
	// Example:
	// If N = 5 then output should be: 2, 3, 5, 7, 11

	public int[] generatePrimeNosFirstN(int n) {
		int[] resultArr = new int[5];
		int i = 2, j = 0;
		while (n > 0) {
			if (isPrime(i)) {
				resultArr[j++] = i;
				n--;
			}
			i++;
		}
		return resultArr;
	}
	
	//	8. Write a program to accept a number from the user and count the number of prime digits in the
	//	given number.Example:
	//	If number = 23897 then output should be: “Number of prime digits in 23897 is: 3”
	public int primeCount(int num) {
		int count = 0,digit;
		while (num > 0) {
			digit = num % 10;
			if(isPrime(digit))
				count++;
			num = num / 10;

		}
		return count;
	}
	
	//	9. Write a program to count the number of words in the given string.
	//	Input String: "core java java core advanced java"
	//	Output: 6
	
	public int wordCount(String str) {
		String[]arr = str.split(" ");
		return arr.length;
	}

}
